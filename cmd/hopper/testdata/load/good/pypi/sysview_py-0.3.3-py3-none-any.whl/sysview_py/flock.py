import fcntl
from contextlib import contextmanager


@contextmanager
def lock_file(file_path):
    f = open(file_path, 'w')
    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
    try:
        yield f
    finally:
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()
