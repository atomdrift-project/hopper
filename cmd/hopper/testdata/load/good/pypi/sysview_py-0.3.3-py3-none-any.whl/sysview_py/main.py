from pathlib import Path
import sys

from .sysview import Sysview
from .flock import lock_file

LOCK_FILE=Path.home() / ".sysview.lock"


def main():
    with lock_file(LOCK_FILE):
        sysview = Sysview()
        db_path = Path.home() / ".sysview.db"
        sysview.setup_db(db_path)
        reports = []
        if not sys.stdin.isatty():
            reports = sysview.read_raw_reports_from_stdin()
        if reports:
            sysview.process_reports(reports)
        sysview.read_hosts()
        sysview.get_latest_reports()
        sysview.update_html()


if __name__ == "__main__":
    main()
