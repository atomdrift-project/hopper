import shutil
import sys
from jinja2 import Environment, PackageLoader, select_autoescape
from pathlib import Path
from .db import SysviewDB
from .report import Report, Host

DEFAULT_DB_PATH = Path.home() / ".sysview.db"
DEFAULT_HTML_PATH = Path.home() / "sysview"
STATIC_FILES_PATH = Path(__file__).parent / "static"



class Sysview:
    status_sort_order = ("UNKNOWN", "CRITICAL", "WARNING", "OK")
    def __init__(self, db=DEFAULT_DB_PATH, hosts=[], reports=[], html_root=DEFAULT_HTML_PATH):
        self.db = db
        self.hosts = hosts
        self.reports = reports
        self.html_root = html_root
        self.html_hosts = html_root / "hosts"

    @property
    def all_services(self):
        items = []
        sorted_items = []
        for host in self.hosts:
            items += host.all_items
        items.sort(key=lambda item: item.status_code, reverse=True)
        return items

    def setup_db(self, db_path):
        self.db = SysviewDB(path=db_path)
        self.db.connect()

    def process_reports(self, raw_reports):
        for raw_report in raw_reports:
            report = Report(raw_report)
            report.parse()
            self.db.add(report)

    def read_hosts(self):
        self.hosts = [
            Host(name=host[0], report_types=host[1]) for host in self.db.get_hosts()
        ]

    def update_html(self):
        shutil.rmtree(self.html_root)
        self.html_root.mkdir(parents=True)
        self.html_hosts.mkdir(parents=True)
        shutil.copytree(STATIC_FILES_PATH, self.html_root / STATIC_FILES_PATH.name)
        env = Environment(
            loader=PackageLoader("sysview_py"),
            autoescape=select_autoescape()
        )
        html = env.get_template("card_view.html").render(items=self.hosts, title="Hosts", active="Hosts", path="", auto_refresh=True)
        html_path = self.html_root / "index.html"
        with open(html_path, 'w') as f:
            f.write(html)
        for host in self.hosts:
            html = env.get_template("card_view.html").render(items=host.all_items, title=host.name, active="Hosts", path="../../", auto_refresh=True)
            host_dir = self.html_hosts / host.name
            host_dir.mkdir()
            html_path = host_dir / "host.html"
            with open(html_path, 'w') as f:
                f.write(html)
            for item in host.all_items:
                html = env.get_template("service.html").render(item=item, title=host.name, active="Services", path="../../", auto_refresh=False)
                html_path = host_dir / f"{item.report_type}_{item.id}.html"
                raw_path = host_dir / f"{item.report_type}_{item.id}.txt"
                with open(html_path, 'w') as f:
                    f.write(html)
                with open(raw_path, 'w') as f:
                    f.write(item.raw_item)
        html = env.get_template("card_view.html").render(items=self.all_services, title="Services", active="Services", path="", auto_refresh=True)
        html_path = self.html_root / f"services.html"
        with open(html_path, 'w') as f:
            f.write(html)

    def get_latest_reports(self):
        for host in self.hosts:
            host.reports = []
            raw_reports = self.db.get_latest_reports(hostname=host.name)
            for report_id, raw_report in raw_reports:
                report = Report(raw_report, report_id=report_id)
                report.parse()
                host.reports.append(report)
            host.reports.sort(key=lambda report: report.status_code, reverse=True)
        self.hosts.sort(key=lambda host: host.status_code, reverse=True)

    @staticmethod
    def read_raw_reports_from_stdin():
        raw_reports = []
        raw_report = ""
        buffer = ""
        identified_fields = 0
        header_fields = ("Hostname:", "Date:", "Type:")
        for raw_line in sys.stdin:
            line = raw_line.rstrip()
            buffer += f"{line}\n"
            possible_header = False
            for field in header_fields:
                if line.startswith(field):
                    identified_fields += 1
                    possible_header = True
                    break
            if identified_fields > 0 and not possible_header:
                identified_fields = 0
            if identified_fields == 3:
                if raw_report:
                    raw_reports.append(raw_report)
                raw_report = buffer
            elif identified_fields == 0:
                raw_report += f"{line}\n"
                buffer = ""
        raw_reports.append(raw_report)
        return raw_reports
