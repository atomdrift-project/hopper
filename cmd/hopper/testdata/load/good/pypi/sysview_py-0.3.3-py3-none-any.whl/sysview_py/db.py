import datetime
import sqlite3


class SysviewDB:
    schema = """
        CREATE TABLE hosts(name, UNIQUE(name));
        CREATE TABLE types(name, UNIQUE(name));
        CREATE TABLE hosts_types(host, type, UNIQUE(host, type));
        CREATE TABLE reports(hostname, type, date, raw_report);
        CREATE TABLE items(command, status, status_text, additional_text, raw_item, report_id);
    """
    def __init__(self, path):
        self.path = path
        self._connection = None
        self._cursor = None

    def connect(self):
        db_exists = False
        if self.path.exists():
            db_exists = True
        self._connection = sqlite3.connect(self.path)
        self._cursor = self._connection.cursor()
        if not db_exists:
            self.init()

    def init(self):
        self._cursor.executescript(self.schema)
        self._connection.commit()

    def get_hosts(self):
        hosts = []
        hostnames = self._cursor.execute("SELECT name FROM hosts").fetchall()
        hostnames = (host[0] for host in hostnames)
        for hostname in hostnames:
            if hostname is None:
                continue
            types = self.get_types(hostname)
            hosts.append((hostname, types))
        return hosts

    def get_types(self, hostname):
        sql = f"SELECT type FROM hosts_types WHERE host = '{hostname}'"
        report_types = self._cursor.execute(sql).fetchall()
        report_types = [report_type[0] for report_type in report_types]
        return report_types

    def get_latest_reports(self, hostname):
        reports = []
        host_types = self.get_types(hostname)
        for host_type in host_types:
            sql = f"SELECT rowid,raw_report  from reports WHERE type = '{host_type}' AND hostname= '{hostname}' ORDER BY rowid DESC LIMIT 1"
            latest_report = self._cursor.execute(sql).fetchone()
            reports.append(latest_report)
        return reports

    def add(self, report):
        report_data = (report.hostname, report.type, report.date, report.raw_report)
        self._cursor.execute("INSERT INTO reports VALUES (?, ?, ?, ?)", report_data)
        report_id = self._cursor.lastrowid

        self._cursor.execute(
            "INSERT OR IGNORE INTO hosts VALUES (?)", (report.hostname,)
        )
        self._cursor.execute("INSERT OR IGNORE INTO types VALUES (?)", (report.type,))
        self._cursor.execute(
            "INSERT OR IGNORE INTO hosts_types VALUES (?,?)",
            (report.hostname, report.type),
        )

        items = [
            (
                i.command,
                i.status,
                i.status_text,
                i.additional_text,
                i.raw_item,
                report_id,
            )
            for i in report.items
        ]
        self._cursor.executemany("INSERT INTO items VALUES(?, ?, ?, ?, ?, ?)", items)

        self._connection.commit()


def adapt_date_iso(val):
    """Adapt datetime.date to ISO 8601 date."""
    return val.isoformat()


def adapt_datetime_iso(val):
    """Adapt datetime.datetime to timezone-naive ISO 8601 date."""
    return val.replace(tzinfo=None).isoformat()


def adapt_datetime_epoch(val):
    """Adapt datetime.datetime to Unix timestamp."""
    return int(val.timestamp())


def convert_date(val):
    """Convert ISO 8601 date to datetime.date object."""
    return datetime.date.fromisoformat(val.decode())


def convert_datetime(val):
    """Convert ISO 8601 datetime to datetime.datetime object."""
    return datetime.datetime.fromisoformat(val.decode())


def convert_timestamp(val):
    """Convert Unix epoch timestamp to datetime.datetime object."""
    return datetime.datetime.fromtimestamp(int(val))


sqlite3.register_converter("date", convert_date)
sqlite3.register_converter("datetime", convert_datetime)
sqlite3.register_converter("timestamp", convert_timestamp)
sqlite3.register_adapter(datetime.date, adapt_date_iso)
sqlite3.register_adapter(datetime.datetime, adapt_datetime_iso)
sqlite3.register_adapter(datetime.datetime, adapt_datetime_epoch)
