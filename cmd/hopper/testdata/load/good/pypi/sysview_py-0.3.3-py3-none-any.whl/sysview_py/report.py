import hashlib
from datetime import datetime, timedelta


status_map = {
        "UNKNOWN": 3,
        "CRITICAL": 2,
        "WARNING": 1,
        "OK": 0
}

class Host:
    def __init__(self, name, report_types=tuple(), reports=[]):
        self.name = name
        self.report_types = report_types
        self.reports = reports
        self.url_path = f"hosts/{self.name}/host.html"

    @property
    def description(self):
        return f"Last updated {self.last_updated}"

    @property
    def last_updated(self):
        last_updated = None
        for report in self.reports:
            if last_updated is None:
                last_updated = report.date
            elif report.date > last_updated:
                last_updated = report.date
        return last_updated

    @property
    def all_items(self):
        items = []
        for report in self.reports:
            for item in report.items:
                item.report_type = report.type
                item.date = report.date
                item.host = self.name
            items += report.items
        items.sort(key=lambda item: item.status_code, reverse=True)
        return items

    @property
    def status(self):
        status = "UNKNOWN"
        report_status = [report.status for report in self.reports]
        if "OK" in report_status:
            status = "OK"
        if "UNKNOWN" in report_status:
            status = "UNKNOWN"
        if "WARNING" in report_status:
            status = "WARNING"
        if "CRITICAL" in report_status:
            status = "CRITICAL"
        return status

    @property
    def status_code(self):
        return status_map[self.status]

    def __repr__(self):
        return f"Host(name={self.name}, status={self.status}, report_types={self.report_types})"


class ReportItem:
    valid_statuses = ("OK", "WARNING", "CRITICAL", "UNKNOWN")

    def __init__(
        self,
        raw_item,
        command=None,
        status="UNKNOWN",
        status_text=None,
        additional_text=None,
        date=None,
        host=None,
        report_type=None,
        report_id=None
    ):
        self.raw_item = raw_item
        self.command = command
        self._status = status
        self.status_text = status_text
        self.additional_text = additional_text
        self.date = date
        self.report_type = report_type
        self.report_id = report_id
        self.host = host

    def __repr__(self):
        return f"ReportItem(command={self.command}, status={self.status})"

    @property
    def description(self):
        return f"{self.status_text}\nUpdated: {self.date}"

    @property
    def name(self):
        return self.command

    @property
    def url_path(self):
        return f"{self.report_type}_{self.id}.html"

    @property
    def status(self):
        age = datetime.now() - self.date
        threshold = timedelta(days=1)
        status = self._status
        if age > threshold:
            status = "UNKNOWN"
        return status

    @status.setter
    def status(self, value):
        self._status = value

    @property
    def status_code(self):
        return status_map[self.status]

    @property
    def id(self):
        return hashlib.sha256((f"{self.report_id}_{self.command}").encode('utf-8')).hexdigest()

    def parse(self):
        parsed_required_fields = False
        self.command = None
        self.status = "UNKNOWN"
        self.status_text = None
        self.additional_text = None
        for line in self.raw_item.split("\n"):
            if None not in (self.command, self.status, self.status_text):
                parsed_required_fields = True
            if line.startswith("Command:") and not parsed_required_fields:
                self.command = ":".join(line.split(":")[1:]).lstrip()
            elif (
                line.split(":")[0] in self.valid_statuses and not parsed_required_fields
            ):
                self.status = line.split(":")[0]
                self.status_text = ":".join(line.split(":")[1:])
            elif parsed_required_fields:
                if self.additional_text is None:
                    self.additional_text = ""
                self.additional_text += f"{line}\n"


class Report:
    def __init__(
        self, raw_report, hostname=None, date=None, report_type=None, items=None, report_id=None
    ):
        self.raw_report = raw_report
        self.hostname = hostname
        self.date = date
        self.type = report_type
        self.items = items
        self.report_id = report_id

    def __repr__(self):
        return f"Report(hostname={self.hostname}, type={self.type}, date={self.date}, status={self.status})"

    @property
    def status(self):
        status = "UNKNOWN"
        item_status = [item.status for item in self.items]
        if "OK" in item_status:
            status = "OK"
        if "WARNING" in item_status:
            status = "WARNING"
        if "CRITICAL" in item_status:
            status = "CRITICAL"
        return status

    @property
    def status_code(self):
        return status_map[self.status]

    def parse(self):
        item_pointer = 0
        raw_report = []
        self.items = []
        raw_item = ""
        for line in self.raw_report.split("\n"):
            raw_report.append(line)
            if line.startswith("Hostname:") and item_pointer == 0:
                self.hostname = line.split(":")[1].strip()
            elif line.startswith("Date:") and item_pointer == 0:
                raw_date = line.replace("Date:", "").strip()
                self.date = datetime.strptime(raw_date, "%a %b %d %X %Z %Y")
            elif line.startswith("Type:") and item_pointer == 0:
                self.type = "".join(line.split(":")[1].strip())
            elif item_pointer > 0 and line != "---":
                raw_item += f"{line}\n"
            elif "---" == line:
                if item_pointer > 0:
                    item = ReportItem(raw_item, report_id=self.report_id, date=self.date)
                    item.parse()
                    self.items.append(item)
                item_pointer = item_pointer + 1
                raw_item = ""
        item = ReportItem(raw_item, report_id=self.report_id, date=self.date)
        item.parse()
        self.items.append(item)
        self.items.sort(key=lambda item: item.status_code, reverse=True)
        self.raw_report = "\n".join(raw_report)
