/*
 * Tailwind v3 preset for consumers. (v4 uses `@import "trivela-ui/theme.css"`
 * instead — see the README.)
 *
 * It maps the colour scale: components are written with `bg-primary-500`,
 * which resolves to nothing unless the consumer's theme knows those names.
 *
 * The `content` entry below is a fallback, NOT something you can rely on.
 * Tailwind v3 does not merge `content` from a preset — a `content` array in
 * the consumer's own config replaces it outright, which every real config
 * has. So the consumer must list the glob themselves:
 *
 *   module.exports = {
 *     presets: [require('trivela-ui/tailwind-preset')],
 *     content: [
 *       './src/**\/*.{ts,tsx}',
 *       './node_modules/trivela-ui/dist/**\/*.js',   // <- required
 *     ],
 *   };
 *
 * Without that second line Tailwind never reads the shipped components, drops
 * every class inside them, and the library arrives invisible with no warning
 * beyond a generic "no utility classes were detected".
 */
const path = require('node:path');

const shades = [100, 200, 300, 400, 500, 600, 700, 800, 900];

const colorNames = [
  'primary',
  'secondary',
  'neutral',
  'success',
  'warning',
  'danger',
  'info',
];

// The values are custom properties, so the actual colours come from
// `trivela-ui/styles.css` and stay themable at runtime.
const colors = Object.fromEntries(
  colorNames.map((name) => [
    name,
    Object.fromEntries(shades.map((shade) => [shade, `var(--color-${name}-${shade})`])),
  ]),
);

module.exports = {
  // Resolved from this file rather than hardcoded, so it survives pnpm's
  // symlinked store and any nesting. Globs need forward slashes on Windows.
  content: [path.join(__dirname, 'dist/**/*.js').split(path.sep).join('/')],
  theme: {
    extend: {
      colors,
    },
  },
};
