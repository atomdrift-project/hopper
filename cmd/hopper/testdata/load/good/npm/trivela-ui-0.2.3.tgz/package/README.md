# Trivela UI

A React component library with one consistent variant and colour system, built on
Tailwind CSS.

## Installation

Both steps are required. Skipping any one of them installs cleanly and
then renders wrong, with no warning.

### 1. Install

```bash
npm install trivela-ui
```

React 18 or 19 is a peer dependency.

### 2. Wire up the CSS

Both lines matter, whichever Tailwind you are on: one registers the colour
scale, the other tells Tailwind to look inside the installed package.

Components are written with classes like `bg-primary-500`. Tailwind only emits
a class it can find as literal text, and it only knows `primary` is a colour if
the scale is registered — so missing either step ships the library invisible.

#### Tailwind v4

```css
/* app.css */
@import "tailwindcss";
@import "trivela-ui/theme.css";
@source "../node_modules/trivela-ui/dist";
```

No JavaScript config needed. `theme.css` declares the palette in `@theme`,
which both registers the colour names and emits the tokens; `@source` points
the scanner at the shipped components. The `@source` path is relative to this
CSS file — adjust the `../` to match where yours lives.

#### Tailwind v3

```tsx
// app/layout.tsx — or wherever your global CSS lives
import 'trivela-ui/styles.css';
```

```js
// tailwind.config.js
module.exports = {
  presets: [require('trivela-ui/tailwind-preset')],
  content: [
    './src/**/*.{ts,tsx}',
    './node_modules/trivela-ui/dist/**/*.js', // required — see below
  ],
};
```

The preset carries the colour scale. The second content line is not optional:
Tailwind v3 does **not** merge `content` from a preset, so your own `content`
array replaces the preset's entirely. Leave it out and Tailwind never reads the
shipped components — every class inside them is dropped and the library renders
with no styling at all.

Either way you also get the parts Tailwind cannot express: the Select arrow and
its dropdown, the Dialog backdrop, and the Toast animation.

## Usage

```tsx
import { Button } from 'trivela-ui';

export function Example() {
  return <Button color="primary">Click me</Button>;
}
```

Most components take `variant` (`solid` | `outline` | `ghost` | `subtle`) and
`color` (`primary` | `secondary` | `success` | `warning` | `danger` | `info` |
`neutral`). A few deliberately do not.

### Theming

The tokens are plain custom properties, so overriding them re-themes every
component at once:

```css
:root {
  --color-primary-500: #7c3aed;
  --color-primary-700: #5b21b6;
}
```

### Client components

`Autocomplete`, `Dialog`, `AlertDialog`, `Tooltip` and `ToastProvider` hold
state or use hooks, and carry `'use client'`. They can be imported from a
server component; they just cannot render on the server. Everything else is
server-safe.

## Toasts

`Toast` on its own is an inline panel. For one that floats, wrap the app once:

```tsx
import { ToastProvider, useToast } from 'trivela-ui';

function App({ children }) {
  return <ToastProvider position="bottom-right">{children}</ToastProvider>;
}

function SaveButton() {
  const { toast } = useToast();
  return (
    <Button onClick={() => toast({ color: 'success', icon: true, title: 'Saved' })}>
      Save
    </Button>
  );
}
```

## License

MIT
