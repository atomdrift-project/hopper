'use strict';
const router = require('events-router');
module.exports = router;
